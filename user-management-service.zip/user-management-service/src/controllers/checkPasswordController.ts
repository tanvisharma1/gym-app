import { Request, Response } from 'express';
import Users from '../models/Users';
import bcrypt from 'bcryptjs';

export const checkPassword = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = req.userId;
    const { password } = req.body;

    const user = await Users.findById(userId);
    if (user) {
      const isMatch = await bcrypt.compare(password, user.hashedPassword);
      if (!isMatch) {
        res.status(403).json({ message: 'Invalid password', t: 0 });
        return;
      } else {
        res.status(200).json({ t: 1, message: 'Valid Password' });
      }
    } else {
      res.status(404).json({ message: 'User is not valid' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error', error });
  }
};

