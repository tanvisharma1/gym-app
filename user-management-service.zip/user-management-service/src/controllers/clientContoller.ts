import { Request, Response } from 'express';
import Users from '../models/Users';
export const getClientById = async (req: Request, res: Response): Promise<void> => {
    try {
      const { clientId } = req.params;

      const client = await Users.findById(clientId).select('-password -hashedPassword -certificates -createdAt -__v -rating -specialization -role')

      // console.log(client);
      if (!client) {
        res.status(404).json({ message: 'Client not found' });
      }
  
     
      res.status(200).json(client);
    } catch (err) {
      res.status(500).json({ message: 'Error fetching client', error: (err as Error).message });
    }
  };