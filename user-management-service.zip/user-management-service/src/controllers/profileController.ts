import { Request, Response } from 'express';
import Users from '../models/Users';

export const updation = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = req.userId;
    const updates = req.body;

    const updatedUser = await Users.findByIdAndUpdate(userId, updates, { new: true });

    if (!updatedUser) {
      res.status(404).json({ message: 'User not found' });
      return;
    }

    res.status(200).json({ message: 'User updated successfully', user: updatedUser });
  } catch (error) {
    res.status(500).json({ message: 'Something went wrong', error });
  }
};
