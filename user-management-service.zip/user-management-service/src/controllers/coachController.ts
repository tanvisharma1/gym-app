// src/controllers/coachController.ts
import { Request, Response } from 'express';
import Users from '../models/Users';
import { getFeedbacks } from '../services/gymService';

export const getAllCoaches = async (_req: Request, res: Response): Promise<void> => {
    try {
      const coaches = await Users.find({ role: 'Coach' }).select('-password -hashedPassword');
      res.status(200).json(coaches); 
    } catch (err) {
      res.status(500).json({ message: 'Error fetching coaches', error: (err as Error).message }); // Ensure err is properly handled
    }
  };


// interface to check if id exists in the database
interface CoachIdParams {
    coachId: string;
  }
  
  export const getCoachById = async (req: Request<CoachIdParams>, res: Response): Promise<void> => {
    try {
      const { coachId } = req.params;

      const coach = await Users.findById(coachId).select('-password -hashedPassword');
      console.log(coach);
      if (!coach || coach.role !== 'Coach') {
        res.status(404).json({ message: 'Coach not found' });
      }
  
     
      res.status(200).json(coach);
    } catch (err) {
      res.status(500).json({ message: 'Error fetching coach', error: (err as Error).message });
    }
  };

//   const GYM_SERVICE_BASE_URL = process.env.GYM_SERVICE_URL || 'http://localhost:5001/api';
//   export const getCoachAvailableSlots = async (req: Request, res: Response) => {
//     try {
//       const { coachId, date } = req.params;
//       const slots = await getAvailableSlots(coachId, date);
//       res.json(slots);
//     } catch (error) {
//       res.status(500).json({ message: 'Error fetching available slots', error: (error as Error).message });
//     }
// };

export const getCoachFeedbacks = async (req: Request, res: Response) => {
  try {
    const { coachId } = req.params;
    const feedbacks = await getFeedbacks(coachId);
    res.json(feedbacks);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching feedbacks', error: err });
  }
};

// import { Request, Response } from 'express';
// import mongoose from 'mongoose';
// import axios from 'axios';

// const Coach = require('../models/Coach');
// const Feedback = require('../models/Feedback');

// // Environment variables for gym service
// const GYM_SERVICE_URL = process.env.GYM_SERVICE_URL || 'http://gym-management-service:3001';

// // Get all coaches
// export const getAllCoaches = async (req: Request, res: Response): Promise<void> => {
//   try {
//     const coaches = await Coach.find({}, { password: 0 });
//     res.status(200).json({
//       success: true,
//       count: coaches.length,
//       data: coaches
//     });
//   } catch (error) {
//     console.error('Error fetching coaches:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Server error',
//       error: (error as Error).message
//     });
//   }
// };

// // Get coach by ID
// export const getCoachById = async (req: Request, res: Response): Promise<void> => {
//   try {
//     const coach = await Coach.findById(req.params.coachId, {
//       password: 0
//     });

//     if (!coach) {
//       res.status(404).json({
//         success: false,
//         message: 'Coach not found'
//       });
//       return;
//     }

//     res.status(200).json({
//       success: true,
//       data: coach
//     });
//   } catch (error) {
//     console.error('Error fetching coach:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Server error',
//       error: (error as Error).message
//     });
//   }
// };

// // Get coach available slots for a specific date
// export const getCoachAvailableSlots = async (req: Request, res: Response): Promise<void> => {
//   try {
//     const { coachId, date } = req.params;
//     const coach = await Coach.findById(coachId);

//     if (!coach) {
//       res.status(404).json({
//         success: false,
//         message: 'Coach not found'
//       });
//       return;
//     }

//     const formattedDate = new Date(date).toISOString().split('T')[0];

//     const response = await axios.get(`${GYM_SERVICE_URL}/api/workouts/coach/${coachId}/date/${formattedDate}`);
//     const workouts = response.data.data || [];

//     const availableSlots = workouts.map((workout: {
//       _id: string;
//       title: string;
//       date: string;
//       startTime: string;
//       endTime: string;
//       isBooked?: boolean;
//     }) => ({
//       workoutId: workout._id,
//       title: workout.title,
//       date: workout.date,
//       startTime: workout.startTime,
//       endTime: workout.endTime,
//       isBooked: workout.isBooked || false
//     }));

//     res.status(200).json({
//       success: true,
//       count: availableSlots.length,
//       data: availableSlots
//     });
//   } catch (error) {
//     console.error('Error fetching available slots:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Server error',
//       error: (error as Error).message
//     });
//   }
// };

// // Get coach feedbacks
// export const getCoachFeedbacks = async (req: Request, res: Response): Promise<void> => {
//   try {
//     const { coachId } = req.params;
//     const coach = await Coach.findById(coachId);

//     if (!coach) {
//       res.status(404).json({
//         success: false,
//         message: 'Coach not found'
//       });
//       return;
//     }

//     const feedbacks = await Feedback.find({
//       to: new mongoose.Types.ObjectId(coachId),
//       fromType: 'client'
//     })
//       .populate({
//         path: 'from',
//         select: 'firstname lastname profilePhoto'
//       })
//       .populate({
//         path: 'booking',
//         populate: {
//           path: 'workout',
//           select: 'title date startTime endTime'
//         }
//       });

//     res.status(200).json({
//       success: true,
//       count: feedbacks.length,
//       data: feedbacks
//     });
//   } catch (error) {
//     console.error('Error fetching coach feedbacks:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Server error',
//       error: (error as Error).message
//     });
//   }
// };
