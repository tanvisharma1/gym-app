import { Request, Response } from 'express';
import Users from '../models/Users';
import bcrypt from 'bcryptjs';

export const updatePassword = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = req.userId;
    const { password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    let user= await Users.findByIdAndUpdate(userId,{password,hashedPassword});
    
    res.status(200).json({message: 'Success',description: 'Updated the password',t:1})
  }
  catch(e:unknown){
     res.status(500).json({message: 'Error',description: 'Internal server error',t:0})
  }
};
