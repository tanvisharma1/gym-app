import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Users from '../models/Users'
import { Request, Response } from 'express';
import Joi from 'joi';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret';

export const passwordRegex = /^(?=.*[A-Z])[^\s]{8,}$/; 
export const nameRegex = /^[A-Za-z]+$/; 

export const isValidPassword = (password: string) => passwordRegex.test(password);
export const isValidName = (name: string) => nameRegex.test(name);

const signupSchema = Joi.object({
  firstName: Joi.string().regex(nameRegex).required().messages({
    'string.pattern.base': 'First name must only contain letters.',
    'any.required': 'First name is required.',
  }),
  lastName: Joi.string().regex(nameRegex).required().messages({
    'string.pattern.base': 'Last name must only contain letters.',
    'any.required': 'Last name is required.',
  }),
  email: Joi.string().email().required().messages({
    'string.email': 'Invalid email format.',
    'any.required': 'Email is required.',
  }),
  password: Joi.string().regex(passwordRegex).required().messages({
    'string.pattern.base': 'Password must be at least 8 characters long, contain one uppercase letter, and have no spaces.',
    'any.required': 'Password is required.',
  }),
  target: Joi.string()
    .valid(
      'Lose weight',
      'Gain weight',
      'Improve flexibility',
      'General fitness',
      'Build Muscle',
      'Rehabilitation/Recovery'
    )
    .required()
    .messages({
      'any.only': 'Target must be one of the predefined values.',
      'any.required': 'Target is required.',
    }),
  preferableActivity: Joi.string()
    .valid(
      'Yoga',
      'Running',
      'Swimming',
      'Cycling',
      'Weight training',
    )
    .required()
    .messages({
      'any.only': 'Preferable activity must be one of the predefined values.',
      'any.required': 'Preferable activity is required.',
    }),
});

export const signup = async (req: Request, res: Response): Promise<void> => {
  try {

    const { error } = signupSchema.validate(req.body, { abortEarly: false });
    if (error) {
      res.status(400).json({ message: 'Validation error', errors: error.details });
      return;
    }

    const { firstName, lastName, email, password, target, preferableActivity, ...rest } = req.body;

    const existingUsers = await Users.findOne({ email });
    if (existingUsers) {
      res.status(400).json({ message: 'Email already exists' });
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const userData = {
      firstName,
      lastName,
      email,
      password,
      hashedPassword,
      role: 'Client', // Always enforce role
      target,
      preferableActivity,
      ...rest,
    };

    // Save the new user
    const newUsers = new Users(userData);
    await newUsers.save();

    res.status(201).json({ message: 'Signup successful' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err });
  }
};

export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    let user = await Users.findOne({ email });
    if (!user) {
      res.status(401).json({ message: 'User does not exist' });
      return;
    }

    const isMatch = await bcrypt.compare(password, user.hashedPassword);
    if (!isMatch) {
      res.status(401).json({ message: 'Invalid password' });
      return;
    }

    const token = jwt.sign(
      { id: user._id, role: user.role, email: user.email },
      JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.status(200).json({ token,role:user.role.toLowerCase() });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err });
  }
};
