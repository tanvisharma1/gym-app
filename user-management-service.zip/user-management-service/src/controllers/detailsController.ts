import { Request, Response } from 'express';
import Users from '../models/Users';

export const details = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = req.userId;
    const role = req.userRole?.toLowerCase();

    if (!userId || !role) {
      res.status(400).json({ message: 'Missing user identification or role.' });
      return;
    }

    const user = await Users.findById(userId).lean();

    if (!user) {
      res.status(404).json({ message: 'User not found.' });
      return;
    }

    if (role === 'client') {
      const clientData = {
        firstName: user.firstName,
        lastName: user.lastName,
        profilePhoto: user.profilePhoto,
        email:user.email,
        target: user.target,
        preferableActivity: user.preferableActivity,
      };
      res.json(clientData);
    } else if(role === 'coach') {
      const coachData = {
        firstName: user.firstName,
        lastName: user.lastName,
        profilePhoto: user.profilePhoto,
        type: user.type,
        email:user.email,
        title: user.title,
        about: user.about,
        summary: user.summary,
        specialization: user.specialization,
        certificates: user.certificates,
        rating: user.rating
      };
      res.json(coachData);
    } else{
      const adminData = {
        firstName: user.firstName,
        lastName: user.lastName,
        profilePhoto: user.profilePhoto,
        email:user.email,
        phoneNumber: user.phoneNumber
      };
      res.json(adminData);
    }
  } catch (error) {
    console.error('Error in user details:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
};
