import mongoose from "mongoose";

const fileDataSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    size: { type: Number, required: true },
    content: { type: String, required: true }, // base64 string
  },
  { _id: false } // prevents automatic _id field creation for subdocuments
);

const userSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  hashedPassword: { type: String, required: true },
  profilePhoto: { type: String, default: "" },
  role: { type: String, default: "Client" },
  type: { type: String },
  target: { type: String },
  phoneNumber: { type: String },
  preferableActivity: { type: String },
  title: { type: String },
  about: { type: String },
  summary: { type: String },
  specialization: [{ type: String }],
  certificates: [fileDataSchema],
  rating: { type: Number, min: 0, max: 5, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model("Users", userSchema);
