import express from 'express';
import cors from 'cors';
import authRoutes from './routes/authRoutes';
import coachRoutes from './routes/coachRoutes';

const app = express();

// Middlewares
app.use(cors());
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));


// Routes
app.use('/api/auth', authRoutes);
app.use('/api', coachRoutes);

// Root endpoint
app.get('/', (_req, res) => {
  res.send('Auth Service is running');
});

export default app;



// import express from 'express';
// import mongoose from 'mongoose';
// import cors from 'cors';
// import dotenv from 'dotenv';

// import authRoutes from './routes/authRoutes.js';
// import coachRoutes from './routes/coachRoutes.js';

// dotenv.config();

// const app = express();

// // Connect to MongoDB
// mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/user-management', {
// }).then(() => {
//   console.log('Connected to MongoDB');
// }).catch(err => {
//   console.error('MongoDB connection error:', err);
//   process.exit(1);
// });

// // Middleware
// app.use(cors());
// app.use(express.json());

// // Routes
// app.use('/api/auth', authRoutes);
// app.use('/api/coaches', coachRoutes);

// // Health check
// app.get('/health', (_req, res) => {
//   res.status(200).json({ message: 'User Management Service is running' });
// });

// // Error handling middleware
// app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
//   console.error(err.stack);
//   res.status(500).json({
//     success: false,
//     message: 'Something went wrong',
//     error: process.env.NODE_ENV === 'production' ? {} : err
//   });
// });

// export default app;
