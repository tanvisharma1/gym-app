import dotenv from 'dotenv';
import app from './app';
import connectDB from './config/db';

dotenv.config();

const PORT = process.env.PORT || 5000;

const startServer = async (): Promise<void> => {
  app.listen(PORT, () => {
    console.log(`Auth Service is running on port ${PORT}`);
  });
  await connectDB();

};

startServer();
