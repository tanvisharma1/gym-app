// src/services/gymService.ts
import axios from 'axios';

const GYM_SERVICE_URL = process.env.GYM_SERVICE_URL || 'http://localhost:5001/api';

// export const getAvailableSlots = async (coachId: string, date: string) => {
//   try {
//     const response = await axios.get(`${GYM_SERVICE_URL}/${coachId}/available-slots/${date}`);
//     return response.data;
//   } catch (error) {
//     throw new Error('Failed to fetch available slots');
//   }
// };

export const getFeedbacks = async (coachId: string) => {
  const response = await axios.get(`${GYM_SERVICE_URL}/feedbacks/coach/${coachId}`);
  return response.data;
};
