// src/routes/coachRoutes.ts
import { Router } from 'express';
import {
  getAllCoaches,
  getCoachById,
  // getCoachAvailableSlots,
  getCoachFeedbacks
} from '../controllers/coachController';

const router = Router();

router.get('/coaches', getAllCoaches);
router.get('/coaches/:coachId', getCoachById);
// router.get('/coaches/:coachId/available-slots/:date', getCoachAvailableSlots);
router.get('/coaches/:coachId/feedbacks', getCoachFeedbacks);

export default router;



// const express = require('express');
// const router = express.Router();
// const coachController = require('../controllers/coachController');

// // Get all coaches
// router.get('/', coachController.getAllCoaches);

// // Get coach by ID
// router.get('/:coachId', coachController.getCoachById);

// // Get coach available slots for a specific date
// router.get('/:coachId/available-slots/:date', coachController.getCoachAvailableSlots);

// // Get coach feedbacks
// router.get('/:coachId/feedbacks', coachController.getCoachFeedbacks);

// module.exports = router;

// export default router;