import { signup, login } from '../controllers/authController';
import { Router } from 'express';
import { updation } from '../controllers/profileController';
import { verifyToken } from '../middlewares/auth.middleware';
import { details } from '../controllers/detailsController';
import { checkPassword } from '../controllers/checkPasswordController';
import { updatePassword } from '../controllers/updatePasswordController';
import { getClientById } from '../controllers/clientContoller';
import { userIdRetrieveal } from '../controllers/gettingId';

const router = Router();

router.post('/signup', signup); 
router.get('/clients/:clientId',getClientById);
router.post('/signin', login);
router.get('/getId', verifyToken ,userIdRetrieveal);
router.put('/update', verifyToken ,updation);
router.get('/details',verifyToken,details)
router.post('/checkpassword',verifyToken,checkPassword)
router.put('/updatepassword',verifyToken,updatePassword)

export default router;



