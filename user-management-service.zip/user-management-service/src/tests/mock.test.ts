describe("Smoke test", () => {
    it("should run successfully", () => {
      expect(true).toBe(true);
    });
  });