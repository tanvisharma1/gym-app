// src/tests/coach.test.ts
import request from 'supertest';
import app from '../app';

describe('Coach Endpoints', () => {
  it('GET /api/coaches should return coaches', async () => {
    const res = await request(app).get('/api/coaches');
    expect(res.statusCode).toBe(200);
  });
});
