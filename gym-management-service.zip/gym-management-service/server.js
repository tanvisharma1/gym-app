// seedFeedbacks.js
const mongoose = require('mongoose');
require('dotenv').config();

// Create the feedback model directly in this file
const feedbackSchema = new mongoose.Schema(
  {
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Booking"
    },
    fromType: {
      type: String,
      enum: ['client', 'coach'],
      required: true
    },
    fromId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    toId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    rating: {
      type: Number,
      min: 1,
      max: 5
    },
    comment: {
      type: String
    },
    fromName: {
      type: String,
      required: true
    },
    toName: {
      type: String,
      required: true
    },
    attendanceDuration: {
      type: String
    },
    sessionType: {
      type: String
    },
    displayDate: {
      type: String
    },
    fromProfileImage: {
      type: String
    }
  },
  { timestamps: true }
);

// Keep the unique index on bookingId and fromType
feedbackSchema.index({ bookingId: 1, fromType: 1 }, { unique: true });

const Feedback = mongoose.model('Feedback', feedbackSchema);

mongoose.connect(process.env.MONGODB_URI || 'mongodb+srv://tanvisharma:Tanvi%400106@cluster0.q5bt05l.mongodb.net/gymManagement', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB Connected for seeding'))
.catch(err => console.log('MongoDB Connection Error:', err));

// Coach IDs and names
const coaches = [
  { id: "680e5ee7e5915679b63c9970", name: "Michael Chen" },
  { id: "680e5ee7e5915679b63c9972", name: "James Rodriguez" },
  { id: "681c8fd952e726c5b39bff98", name: "Emmas Johnson" },
  { id: "680e5ee7e5915679b63c9971", name: "Sarah Patel" },
  { id: "680e5ee7e5915679b63c9973", name: "Olivia Smith" },
  { id: "681f81632c5515725c3147f9", name: "Cameron Williamson" },
  { id: "681f82ac2c5515725c3147fb", name: "Brooklyn Simmons" },
  { id: "681f84b72c5515725c3147fc", name: "Guy Hawkins" },
  { id: "680e5ee7e5915679b63c996f", name: "Kristie Watson" }
];

// Client IDs, names, and profile images
const clients = [
  { 
    id: "681c8f17f2ddad7aceea8859", 
    name: "Medina Williams", 
    profileImage: "https://randomuser.me/api/portraits/women/1.jpg" 
  },
  { 
    id: "681ca183af8c073c5bf1682c", 
    name: "Rajat Chauhan", 
    profileImage: "https://randomuser.me/api/portraits/men/2.jpg" 
  },
  { 
    id: "681c7ac95edcf11d51f2fac5", 
    name: "Serena Williams", 
    profileImage: "https://randomuser.me/api/portraits/women/3.jpg" 
  },
  { 
    id: "681b4e54532a4f8dfdefd65e", 
    name: "Ester", 
    profileImage: "https://randomuser.me/api/portraits/men/4.jpg" 
  },
  { 
    id: "681b57b495f2268871268780", 
    name: "David Beckham", 
    profileImage: "https://randomuser.me/api/portraits/men/5.jpg" 
  },
  { 
    id: "681b4eee532a4f8dfdefd666", 
    name: "Cris Santos", 
    profileImage: "https://randomuser.me/api/portraits/women/6.jpg" 
  },
  { 
    id: "681b4e46532a4f8dfdefd65b", 
    name: "Neymar Junior", 
    profileImage: "https://randomuser.me/api/portraits/men/7.jpg" 
  },
  { 
    id: "681b4e46532a4f8dfdefd65c", 
    name: "Amanda", 
    profileImage: "https://i.postimg.cc/8cLTKn8L/Avatar-8.png"  
  }
];

// Session types
const sessionTypes = [
  "Yoga",
  "Strength Training",
  "HIIT",
  "Pilates",
  "CrossFit",
  "Cardio",
  "Meditation",
  "Personal Training",
  "Group Class",
  "One-on-one"
];

// Duration periods
const durations = [
  "two months",
  "three months",
  "four months",
  "five months",
  "six months",
  "one year",
  "eight weeks"
];

// Generate a random comment
const generateComment = () => {
  const comments = [
    "I've been attending classes with {coach} for {duration}, and the transformation in my flexibility and overall well-being has been amazing. The consistency and guidance have helped me establish a strong routine. Highly recommend for anyone looking to embrace their fitness practice!",
    "Thank you for the amazing sessions! Your clear instructions and encouragement helped me achieve more than I thought possible.",
    "Great coach! Very patient and knowledgeable. I've seen significant improvement in my technique. I appreciate your attention to detail and focus on correct form. It's prevented injuries.",
    "Your coaching style is perfect for me - not too pushy but encouraging when needed. I appreciate how you adapt the exercises to my level while gradually increasing difficulty. Great coach! Very patient and knowledgeable.",
    "Excellent at pushing me beyond my comfort zone while ensuring proper form. Would highly recommend! I appreciate your attention to detail and focus on correct form. It's prevented injuries.",
    "The personalized workout plan was exactly what I needed. Thank you for listening to my goals. I appreciate your attention to detail and focus on correct form. It's prevented injuries.",
    "Very professional and motivating. Makes every session challenging but fun. Thank you for listening to my goals.  I appreciate your attention to detail and focus on correct form. It's prevented injuries.",
    "I appreciate how you adapt the exercises to my level while gradually increasing difficulty.Great coach! Very patient and knowledgeable. I've seen significant improvement in my technique.",
    "Your coaching style is perfect for me - not too pushy but encouraging when needed.Thank you for listening to my goals.  I appreciate your attention to detail and focus on correct form.",
    "I've tried many coaches before, but your approach to fitness is by far the most effective.I've seen significant improvement in my technique. Your positive energy is contagious! I always leave our sessions feeling motivated.",
    "Thanks for the detailed explanations during our sessions. It helps me understand the purpose behind each exercise. Your positive energy is contagious! I always leave our sessions feeling motivated.",
    "Your positive energy is contagious! I always leave our sessions feeling motivated. I've seen significant improvement in my technique. I appreciate your attention to detail and focus on correct form. It's prevented injuries.",
    "The progress I've made under your guidance is remarkable. Thank you for your expertise.Great coach! Very patient and knowledgeable. I've seen significant improvement in my technique.",
    "I appreciate your attention to detail and focus on correct form. It's prevented injuries. Your positive energy is contagious! I always leave our sessions feeling motivated. I've seen significant improvement in my technique.",
    "Your holistic approach to fitness and wellness has changed my perspective entirely.Great coach! Very patient and knowledgeable. I've seen significant improvement in my technique.",
    "Sessions with you are challenging but incredibly rewarding. Looking forward to continuing. I appreciate your attention to detail and focus on correct form. It's prevented injuries. Your positive energy is contagious! I always leave our sessions feeling motivated.",
  ];
  
  const randomComment = comments[Math.floor(Math.random() * comments.length)];
  return randomComment;
};

// Function to replace placeholders in comments
const formatComment = (comment, coachName, duration) => {
  return comment.replace('{coach}', coachName).replace('{duration}', duration);
};

// Generate a random rating between 4 and 5
const generateRating = () => {
  return Math.floor(Math.random() * 2) + 4; // Generates either 4 or 5
};

// Generate a random date from the last 6 months
const generateDisplayDate = () => {
  const today = new Date();
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(today.getMonth() - 6);
  
  const randomDate = new Date(
    sixMonthsAgo.getTime() + Math.random() * (today.getTime() - sixMonthsAgo.getTime())
  );
  
  return randomDate.toLocaleDateString();
};

// Create feedback data
const createFeedbacks = async () => {
  try {
    // Clear existing feedbacks
    await Feedback.deleteMany({});
    
    // Try to get real booking IDs from the database
    let bookingIds = [];
    try {
      const bookings = await mongoose.connection.collection('bookings').find({}).toArray();
      if (bookings && bookings.length > 0) {
        console.log(`Found ${bookings.length} real bookings in the database`);
        bookingIds = bookings.map(booking => booking._id);
      } else {
        console.log('No real bookings found in the database');
      }
    } catch (err) {
      console.log('Error fetching bookings:', err.message);
      console.log('Will use generated booking IDs instead');
    }
    
    const feedbacks = [];
    let bookingIdIndex = 0;
    const totalFeedbacksNeeded = coaches.length * 10;
    
    // Ensure each coach has exactly 10 feedbacks
    for (const coach of coaches) {
      const numFeedbacks = 10;
      
      for (let i = 0; i < numFeedbacks; i++) {
        // Randomly select a client
        const client = clients[Math.floor(Math.random() * clients.length)];
        
        // Get a booking ID - use real one if available, otherwise create new
        let bookingId;
        if (bookingIdIndex < bookingIds.length) {
          bookingId = bookingIds[bookingIdIndex++];
        } else {
          bookingId = new mongoose.Types.ObjectId();
        }
        
        // Select a random session type
        const sessionType = sessionTypes[Math.floor(Math.random() * sessionTypes.length)];
        
        // Select a random duration
        const attendanceDuration = durations[Math.floor(Math.random() * durations.length)];
        
        // Generate comment and replace placeholders
        const baseComment = generateComment();
        const comment = formatComment(baseComment, coach.name, attendanceDuration);
        
        // Generate a display date
        const displayDate = generateDisplayDate();
        
        // Create special feedback for Kristie Watson from Amanda (matching the image)
        if (coach.name === "Kristie Watson" && i === 0) {
          const amandaClient = clients.find(c => c.name === "Amanda");
          feedbacks.push({
            bookingId: new mongoose.Types.ObjectId(), // Always use a new ID for this special case
            fromType: 'client',
            fromId: amandaClient.id,
            toId: coach.id,
            rating: 5,
            comment: "I've been attending classes with Kristie Watson for six months, and the transformation in my flexibility and overall well-being has been amazing. Highly recommend for anyone looking to embrace their yoga practice!",
            fromName: "Amanda",
            toName: "Kristie Watson",
            attendanceDuration: "six months",
            sessionType: "Yoga",
            displayDate: "4/17/2024",
            fromProfileImage: amandaClient.profileImage
          });
        } else {
          feedbacks.push({
            bookingId,
            fromType: 'client',
            fromId: client.id,
            toId: coach.id,
            rating: generateRating(),
            comment,
            fromName: client.name,
            toName: coach.name,
            attendanceDuration,
            sessionType,
            displayDate,
            fromProfileImage: client.profileImage
          });
        }
      }
    }
    
    // Insert feedbacks into the database
    await Feedback.insertMany(feedbacks);
    
    // Calculate how many real vs generated booking IDs were used
    const realBookingsUsed = Math.min(bookingIds.length, totalFeedbacksNeeded);
    const generatedBookingsUsed = totalFeedbacksNeeded - realBookingsUsed;
    
    console.log(`Successfully inserted ${feedbacks.length} feedbacks`);
    console.log(`Each coach has exactly 10 feedbacks`);
    console.log(`Used ${realBookingsUsed} real booking IDs and generated ${generatedBookingsUsed} new booking IDs`);
    
    // Print a summary of feedbacks per coach
    for (const coach of coaches) {
      const count = feedbacks.filter(f => f.toId === coach.id).length;
      console.log(`${coach.name}: ${count} feedbacks`);
    }
    
    // Disconnect from MongoDB
    mongoose.disconnect();
  } catch (error) {
    console.error('Error seeding feedbacks:', error);
    mongoose.disconnect();
    process.exit(1);
  }
};

createFeedbacks();