// feedbackModel.js
const mongoose = require('mongoose');

const feedbackSchema = new mongoose.Schema(
  {
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Booking"
    },
    fromType: {
      type: String,
      enum: ['client', 'coach'],
      required: true
    },
    fromId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    toId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    rating: {
      type: Number,
      min: 1,
      max: 5
    },
    comment: {
      type: String
    },
    fromName: {
      type: String,
      required: true
    },
    toName: {
      type: String,
      required: true
    },
    attendanceDuration: {
      type: String
    },
    sessionType: {
      type: String
    },
    displayDate: {
      type: String
    },
    fromProfileImage: {
      type: String
    }
  },
  { timestamps: true }
);

feedbackSchema.index({ bookingId: 1, fromType: 1 }, { unique: true });

const Feedback = mongoose.model('Feedback', feedbackSchema);

module.exports = Feedback;