import express from 'express';
import {bookWorkout, cancelWorkout, getWorkoutsOfClient, getWorkoutsOfCoach,getAllWorkouts} from '../controllers/booking.controller'
import { verifyToken } from '../middlewares/auth.middleware';

const router = express.Router();

// GET /workouts/booked
router.get('/bookings/all', getAllWorkouts);

// GET /workouts/booked
router.get('/workouts/bookedclient',verifyToken, getWorkoutsOfClient);

// POST /workouts
router.post('/workouts',verifyToken, bookWorkout);

//GET workout for coach
router.get('/workouts/bookedcoaches', verifyToken,getWorkoutsOfCoach);

// DELETE /workouts/:workoutId
router.post('/workouts/cancel', verifyToken,cancelWorkout);

export default router;

