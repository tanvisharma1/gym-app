import express from 'express';
import { getAvailableSlots,getFilteredWorkouts } from '../controllers/workoutController';

const router = express.Router();

// GET /coaches/:coachId/available-slots/:date
router.get('/coaches/:coachId/available-slots/:date', getAvailableSlots);


router.get('/filterworkouts', getFilteredWorkouts);

export default router;
