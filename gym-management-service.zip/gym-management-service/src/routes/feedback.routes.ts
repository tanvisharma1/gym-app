import express from "express";
import { addFeedback, getCoachFeedbacks } from "../controllers/feedback.controller";
import { verifyToken } from "../middlewares/auth.middleware";

export const feedbackrouter = express.Router();

// router.get("/", getUsers);
feedbackrouter.post("/addFeedback", verifyToken,addFeedback);
feedbackrouter.get("/coaches/:coachId/feedbacks",getCoachFeedbacks);


