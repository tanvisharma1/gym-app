// import dotenv from 'dotenv';
// import express from 'express';
// import connectDB from './config/db';
// import userRoutes from './routes/workoutRoutes';
// import { errorHandler } from './middlewares/error.middleware';
// import Workout from './models/workout.model';


// dotenv.config();

// // Connect to MongoDB
// connectDB();

// const app = express();

// // Middleware
// app.use(express.json());

// // Error handler
// app.use(errorHandler);

// // Routes
// app.use('/api/users',  workoutRoutes);

// const PORT = process.env.PORT || 5001;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });



import dotenv from 'dotenv';
import app from './app';
import connectDB from './config/db';
// server.ts or app.ts
import './scheduler'; // This starts the cron job when server starts

dotenv.config();

const PORT = process.env.PORT || 5001;

const startServer = async (): Promise<void> => {
  try {
    await connectDB(); // Ensure DB connection before starting the server
    app.listen(PORT, () => {
      console.log(`Gym Management Service is running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start Gym Management Service:', error);
    process.exit(1);
  }
};

startServer();
