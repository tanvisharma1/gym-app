import mongoose, { Document, Schema, Model } from 'mongoose';

export interface WorkoutAttrs {
  coach: mongoose.Types.ObjectId;
  type: string,
  title: string;
  workoutType:string,
  description?: string;
  date: string; // Format: "YYYY-MM-DD"
  startTime: string; // Format: "HH:mm"
  endTime: string;   // Format: "HH:mm"
}

export interface WorkoutDoc extends Document, WorkoutAttrs {
  createdAt: Date;
}

const workoutSchema = new Schema<WorkoutDoc>(
  {
    coach: {
      type: Schema.Types.ObjectId,
      required: true,
    },
    workoutType:{
      type: String,
      required: true
    },
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    date: {
      type: String,
      required: true,
    },
    startTime: {
      type: String,
      required: true,
    },
    endTime: {
      type: String,
      required: true,
    },
  
    
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: false } // or set to true if you want updatedAt too
);

const Workout: Model<WorkoutDoc> = mongoose.model<WorkoutDoc>('Workout', workoutSchema);

export default Workout;
