import mongoose, { Document, Schema, Model } from 'mongoose';

export type BookingStatus = 'booked' | 'cancelled' | 'completed';

export interface BookingAttrs {
  workout: mongoose.Types.ObjectId;
  client: mongoose.Types.ObjectId;
  status: BookingStatus;
  statusOfFeedback?: [boolean, boolean]; // Include this to match schema
}

export interface BookingDoc extends Document, BookingAttrs {
  createdAt: Date;
  updatedAt: Date;
}

const bookingSchema = new Schema<BookingDoc>(
  {
    workout: {
      type: Schema.Types.ObjectId,
      ref: "Workout",
      required: true,
      unique: true,
    },
    client: {
      type: Schema.Types.ObjectId,
      required: true,
    },
    status: {
      type: String,
      enum: ['booked', 'cancelled', 'completed'],
      default: 'booked',
    },
    statusOfFeedback: {
      type: [Boolean],
      default: [false, false], // [coachFeedback, clientFeedback]
    },
  },
  { timestamps: true }
);

const Booking: Model<BookingDoc> = mongoose.model<BookingDoc>('Booking', bookingSchema);

export default Booking;
