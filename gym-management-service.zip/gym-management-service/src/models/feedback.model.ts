// import mongoose, { Document, Schema, Model } from 'mongoose';

// export type FromType = 'client' | 'coach';

// export interface FeedbackAttrs {
//   bookingId: mongoose.Types.ObjectId;
//   fromType: FromType;
//   fromId: mongoose.Types.ObjectId;
//   toId: mongoose.Types.ObjectId;
//   rating: number; 
//   comment: string;
// }

// export interface FeedbackDoc extends Document, FeedbackAttrs {
//   createdAt: Date;
//   updatedAt: Date;
// }

// const feedbackSchema = new Schema<FeedbackDoc>(
//   {
//     bookingId: {
//       // type: String,
//       type: mongoose.Schema.Types.ObjectId,
//       required: true,
//       ref:"Booking"
//     },
//     fromType: {
//       type: String,
//       // type: mongoose.Schema.Types.ObjectId,
//       enum: ['client', 'coach'],
//       required: true
//     },
//     fromId: {
//       // type: String,
//        type: mongoose.Schema.Types.ObjectId,
//       required: true
//     },
//     toId: {
//       // type: String,
//        type: mongoose.Schema.Types.ObjectId,
//       required: true
//     },
//     rating: {
//       type: Number,
//       min: 1,
//       max: 5
//     },
//     comment: {
//       type: String
//     }
//   }
// );
// feedbackSchema.index({ bookingId: 1, fromType: 1 }, { unique: true });


// const Feedback: Model<FeedbackDoc> = mongoose.model<FeedbackDoc>('Feedback', feedbackSchema);

// export default Feedback;


// Updated Feedback Schema with profile image
import mongoose, { Document, Schema, Model } from 'mongoose';

export type FromType = 'client' | 'coach';

export interface FeedbackAttrs {
  bookingId: mongoose.Types.ObjectId;
  fromType: FromType;
  fromId: mongoose.Types.ObjectId;
  toId: mongoose.Types.ObjectId;
  rating: number; 
  comment: string;
  fromName: string;
  toName: string;
  attendanceDuration: string;
  sessionType: string;
  displayDate: string;
  fromProfileImage: string; // New field for client profile image
}

export interface FeedbackDoc extends Document, FeedbackAttrs {
  createdAt: Date;
  updatedAt: Date;
}

const feedbackSchema = new Schema<FeedbackDoc>(
  {
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Booking"
    },
    fromType: {
      type: String,
      enum: ['client', 'coach'],
      required: true
    },
    fromId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    toId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    rating: {
      type: Number,
      min: 1,
      max: 5
    },
    comment: {
      type: String
    },
    fromName: {
      type: String,
      required: true
    },
    toName: {
      type: String,
      required: true
    },
    attendanceDuration: {
      type: String
    },
    sessionType: {
      type: String
    },
    displayDate: {
      type: String
    },
    fromProfileImage: {
      type: String
    }
  },
  { timestamps: true }
);

feedbackSchema.index({ bookingId: 1, fromType: 1 }, { unique: true });

const Feedback: Model<FeedbackDoc> = mongoose.model<FeedbackDoc>('Feedback', feedbackSchema);

export default Feedback;