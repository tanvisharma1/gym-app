// scheduler.ts
import cron from 'node-cron';
import { updateCompletedBookingsLogic } from './controllers/autoUpdateBookings';

// Run every hour at minute 0
cron.schedule('0 * * * *', async () => {
  console.log('⏰ Running hourly booking status check...');
  try {
    await updateCompletedBookingsLogic();
    console.log('✅ Booking statuses updated.');
  } catch (err) {
    console.error('❌ Failed to update bookings:', err);
  }
});
