import express from "express";
import cors from "cors";
import helmet from "helmet";
// import userRoutes from "./routes/user.routes";
import workoutRoutes from './routes/workoutRoutes';
import bookingRoutes from './routes/bookingRoutes'
import { errorHandler } from './middlewares/error.middleware';
import { feedbackrouter } from "./routes/feedback.routes";
const app = express();

app.use(cors());
app.use(express.json());
app.use(cors())
// Mount route
// app.use('/api/bookings', bookingRoutes);

// app.use("/api/users", userRoutes);
app.use('/api', workoutRoutes);
app.use('/api', bookingRoutes);
app.use('/api',feedbackrouter);
export default app;


 