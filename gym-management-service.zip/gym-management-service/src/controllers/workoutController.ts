import { Request, Response } from 'express';
import Workout from '../models/workout.model';
import mongoose from 'mongoose';

// Controller function to get available slots for a coach on a given date
export const getAvailableSlots = async (req: Request, res: Response) => {
  try {
    const { coachId, date } = req.params;
    const changedData={
        coach: new mongoose.Types.ObjectId(coachId),
        date}
        console.log(changedData)

    const workouts = await Workout.find(changedData).select('startTime endTime');

    const availableSlots = workouts.map((workout) => ({
      startTime: workout.startTime,
      endTime: workout.endTime,
    }));

    res.status(200).json({ slots: availableSlots });
  } catch (error) {
    res.status(500).json({
      message: 'no slots available',
      error: (error as Error).message,
    });
  }
};

export const getFilteredWorkouts = async (req: Request, res: Response) => {
  try {
    const { type, date, startTime, coachId } = req.query;

    const filter: any = {};

    if (type) filter.type = type;
    if (date) filter.date = date;
    if (startTime) filter.startTime = startTime;
    if (coachId) filter.coach = coachId;

    const workouts = await Workout.find(filter)
      .populate('coach', 'name') // assumes coach is referenced by ObjectId and you want name
      .exec();

    res.status(200).json(workouts);
  } catch (error: any) {
    res.status(500).json({ message: 'Failed to fetch workouts', error: error.message });
  }
};

