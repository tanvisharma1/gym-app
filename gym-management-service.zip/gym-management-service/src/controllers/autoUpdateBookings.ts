import { Request, Response } from 'express';
import Booking from '../models/booking.model';
import mongoose from 'mongoose';

// Utility function to check if workout has ended
const hasSessionEnded = (dateStr: string, endTime: string): boolean => {
  const [year, month, day] = dateStr.split('-').map(Number);
  const [hours, minutes] = endTime.split(':').map(Number);
  const endDateTime = new Date(year, month - 1, day, hours, minutes);
  return new Date() > endDateTime;
};

// ✅ Core logic for both API and cron
export const updateCompletedBookingsLogic = async (): Promise<void> => {
  const bookings = await Booking.find({ status: 'booked' }).populate({
    path: 'workout',
    select: 'endTime date',
  });

  const updates = bookings.map(async (booking) => {
    const workout = booking.workout as unknown as { date: string; endTime: string };
    if (
      workout?.date &&
      workout?.endTime &&
      hasSessionEnded(workout.date, workout.endTime)
    ) {
      booking.status = 'completed';
      return booking.save();
    }
    return null;
  });

  await Promise.all(updates);
};

// ✅ API handler for manual trigger
export const updateCompletedBookings = async (req: Request, res: Response) => {
  try {
    await updateCompletedBookingsLogic();
    res.status(200).json({
      message: 'Booking statuses updated where applicable.',
    });
  } catch (error: any) {
    res
      .status(500)
      .json({ message: 'Error updating bookings', error: error.message || error });
  }
};
