import { Request, Response } from 'express';
import Booking from '../models/booking.model';
import Workout from '../models/workout.model';

// Book a workout
export const bookWorkout = async (req: Request, res: Response): Promise<void> => {
 try {
    const clientId = req.userId;
    const { workoutId } = req.body;

    // 1. Validate workout existence
    const workout = await Workout.findById(workoutId);
    if (!workout) {
      res.status(404).json({ message: 'Workout not found' });
      return;
    }

    // 2. Check if already booked
    const existingBooking = await Booking.findOne({ workout: workout._id });
    if (existingBooking) {
      res.status(409).json({ message: 'This workout is already booked' });
      return;
    }

    // 3. Create booking
    const newBooking = new Booking({
      workout: workout._id,
      client: clientId,
      status: 'booked',
    });

    await newBooking.save();

    res.status(201).json({
      message: 'Workout booked successfully',
      booking: newBooking,
    });
  } catch (error) {
    console.error('Booking Error:', error);
    res.status(500).json({
      message: 'Internal server error',
      error: (error as Error).message,
    });
  }
};

// Get all the booked workouts for all the coaches
export const getAllWorkouts = async (req: Request, res: Response): Promise<void> => {
  try {
    const bookings = await Booking.find()
      .select('-createdAt -updatedAt -__v') // Exclude internal fields
      .populate({
        path: 'workout',
        select: 'coach workoutType description startTime date',
      })
      .populate({
        path: 'client',
        select: 'firstName lastName email', // Optional: include client info
      });

    res.status(200).json({ bookings });
  } catch (err) {
    res.status(500).json({
      message: 'Failed to fetch all bookings',
      error: (err as Error).message,
    });
  }
};

// Get all workouts for a coach
export const getWorkoutsOfClient= async (req: Request, res: Response): Promise<void> => {
   const clientId = req.userId; 
  try {
    const bookings = await Booking.find({ client: clientId })
  .select('-createdAt -updatedAt -__v') // 👈 exclude unwanted fields
  .populate({
    path: 'workout',
    select: 'coach workoutType description startTime date',
  });
    res.status(200).json({ bookings });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch client bookings', error: (err as Error).message });
  }
};
 
// Get all booked workouts
export const getWorkoutsOfCoach = async (req: Request, res: Response): Promise<void> => {
  const coachId = req.userId; // Assume from middleware
  try {
    // 1. Get all workout IDs created by this coach
    const workouts = await Workout.find({ coach: coachId }).select('_id');

    const workoutIds = workouts.map((w) => w._id);

    // 2. Find all bookings for these workouts
    const bookings = await Booking.find({ workout: { $in: workoutIds } }).select('-createdAt -updatedAt -__v') 
      .populate({
        path: 'workout',
        select: 'coach workoutType description startTime date',
      })
      // Optional: if you also want client info

    res.status(200).json({ bookings });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch bookings', error: (err as Error).message });
  }
};

// Cancel a workout booking
export const cancelWorkout = async (req: Request, res: Response): Promise<void> => {
  try {
    const { bookingId } = req.body;
    const cancellationStatus ="cancelled";
    const query = {
      _id: bookingId,
    };

    const booking = await Booking.findOneAndUpdate(query, { status: cancellationStatus }, { new: true });

    if (!booking) {
      res.status(404).json({
        message: 'Booking not found or user not authorized to cancel',
      });
      return;
    }

    res.status(200).json({ message: 'Workout cancelled', booking });
  } catch (error) {
    res.status(500).json({
      message: 'Error cancelling workout',
      error: (error as Error).message,
    });
  }
};
 