import { Request, Response } from 'express';
import Feedback, { FeedbackAttrs } from '../models/feedback.model';
import Booking from '../models/booking.model';
import mongoose from 'mongoose';

export const addFeedback = async (req: Request, res: Response):Promise<void> => {
  try {
    const body=req.body;
    if (!req.userRole) {
  res.status(400).json({ message: 'User role is required' });
  return;
}
if(!req.userId){
  res.status(400).json({ message: 'User not authenticated' });
  return;
}
    // Import mongoose at the top if not already imported
    // import mongoose from 'mongoose';

    const feedback:FeedbackAttrs={
      bookingId: body.bookingId,
      fromType: req.userRole.toLowerCase() as 'client' | 'coach',
      fromId: new (require('mongoose')).Types.ObjectId(req.userId),
      toId: body.toId,
      rating: body.rating,
      comment: body.comment,
      fromName: 'hello',
      toName: 'hello',
      attendanceDuration: 'hello',
      sessionType: 'hello',
      displayDate: 'hello',
      fromProfileImage: 'https://i.postimg.cc/R0xmXzFB/Avatar-4.png'
    }
    
    const newFeedback = await Feedback.create(feedback);
    const booking = await Booking.findById(body.bookingId);
if (!booking) {
   res.status(404).json({ message: "Booking not found" });
   return ;
}

const updatedStatus = [...(booking.statusOfFeedback || [false, false])];
// console.log(req.userRole)
if (req.userRole.toLowerCase() === "coach") {
  updatedStatus[0] = true;
} else if (req.userRole.toLowerCase() === "client") {
  updatedStatus[1] = true;
}

const updatedBooking = await Booking.findByIdAndUpdate(
  body.bookingId,
  { statusOfFeedback: updatedStatus },
  { new: true }
);

res.status(201).json({
  message: 'Feedback created successfully',
  data: newFeedback,
  booking: updatedBooking,
});
  } catch (error: any) {
     res.status(400).json({
      message: 'Failed to create feedback',
      error: error.message || error
    });
  }
};


export const getCoachFeedbacks = async (req: Request, res: Response): Promise<void> => {
  try {
    const { coachId } = req.params;

    
    if (!mongoose.Types.ObjectId.isValid(coachId)) {
      res.status(400).json({ 
        message: 'Invalid coach ID format' 
      });
      return;
    }

    
    const feedbacks = await Feedback.find({ toId: coachId })
      .sort({ createdAt: -1 }) 
      .lean();

    // Format the feedback data for frontend display
    const formattedFeedbacks = feedbacks.map(feedback => ({
      ...feedback,
      
      formattedDate: feedback.displayDate || new Date(feedback.createdAt).toLocaleDateString()
    }));

    res.status(200).json({
      message: 'Feedbacks retrieved successfully',
      count: formattedFeedbacks.length,
      data: formattedFeedbacks || []
    });
  } catch (error: any) {
    console.error('Error fetching coach feedbacks:', error);
    res.status(400).json({
      message: 'Failed to fetch feedbacks',
      error: error.message || error
    });
  }
};

// Add a new method to create feedback with the enhanced fields
export const createFeedback = async (req: Request, res: Response): Promise<void> => {
  try {
    const { 
      bookingId, 
      fromType, 
      fromId, 
      toId, 
      rating, 
      comment,
      fromName,
      toName,
      attendanceDuration,
      sessionType,
      fromProfileImage
    } = req.body;

    // Validate required fields
    if (!bookingId || !fromType || !fromId || !toId || !rating) {
      res.status(400).json({ message: 'Missing required fields' });
      return;
    }

    
    const displayDate = new Date().toLocaleDateString();

    const feedback = new Feedback({
      bookingId,
      fromType,
      fromId,
      toId,
      rating,
      comment,
      fromName,
      toName,
      attendanceDuration,
      sessionType,
      displayDate,
      fromProfileImage
    });

    await feedback.save();

    res.status(201).json({
      message: 'Feedback submitted successfully',
      data: feedback
    });
  } catch (error: any) {
    console.error('Error creating feedback:', error);
    
    // Handle duplicate feedback
    if (error.code === 11000) {
      res.status(400).json({
        message: 'You have already submitted feedback for this booking',
        error: 'Duplicate feedback'
      });
      return;
    }
    
    res.status(400).json({
      message: 'Failed to submit feedback',
      error: error.message || error
    });
  }
};